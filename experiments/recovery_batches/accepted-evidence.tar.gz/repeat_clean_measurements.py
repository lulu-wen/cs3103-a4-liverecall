import fcntl
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from run_other_evidence import run_phase

python = "/home/lulumi/cs3103-a4-test-xCtjouWF/.venv/bin/python"
with (ROOT / "experiment.lock").open("a") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    previous = ROOT / "superseded_overlap"
    previous.mkdir(exist_ok=True)
    for path in (ROOT / "evidence").iterdir():
        if path.name.startswith(("t4", "rss300")):
            path.rename(previous / path.name)
    print("Preserved overlapping measurements; restarting T4", flush=True)
    run_phase(ROOT, python, "t4", 100, 60,
              ["--disconnect-percent", "20", "--disconnect-at", "15", "--disconnect-seconds", "5"])
subprocess.run([python, str(ROOT / "current/experiments/recovery_batches/run_memory.py"),
                "--root", str(ROOT), "--python", python], check=True)
